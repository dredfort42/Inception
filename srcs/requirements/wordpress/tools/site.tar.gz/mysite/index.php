<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">

<title>Made by dredfort</title>

<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta name="description" content="Made by dredfort">
<meta name="keywords" content="School21, inception">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">

</head>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

<div class="container">
     <div class="row">
          <section id="home" class="parallax-section">

               <div class="col-md-offset-1 col-md-10 col-sm-12">
                    <div class="home-wrapper">
                         <h3>INCEPTION</h3>
                         <h1>Made by dredfort</h1>
                    </div>
               </div>

          </section>
     </div>
</div>

<section id="about" class="parallax-section">
     <div class="container">
          <div class="row">

               <div class="col-md-4 col-sm-8">
                    <img src="images/about-image.jpg" class="wow fadeInUp img-responsive" data-wow-delay="0.2s" alt="about image">
                    <div class="wow fadeInUp" data-wow-delay="0.4s">
                         <h4>Interested in seeing other work?</h4>
                         <p>Follow me on GitHub!</p>
                         <a href="https://github.com/dredfort42">https://github.com/dredfort42</a>
                    </div>
               </div>

               <div class="col-md-8 col-sm-12">
                    <div class="about-thumb">
                         <div class="wow fadeInUp section-title" data-wow-delay="0.6s">
                              <h3>Inception summary:</h3>
                              <h2>This document is a System Administration related exercise.</h2>
                         </div>
                         <div class="wow fadeInUp" data-wow-delay="0.8s">
                              <p>This project aims to broaden your knowledge of <b>system administration</b> by using <b>Docker</b>.<br>
                                   You will virtualize several Docker images, creating them in your new personal <b>virtual machine</b>.</p>
                         </div>
                    </div>
               </div>

          </div>
     </div>
</section>

</body>
</html>